package com.info.main;

import com.info.domain.model.Bank;

import java.util.Scanner;

public class EntryClass {


  public  static void helperTest()
  {
    for(int i=0;i<20;i++)
    {
      int j=i+1;
    }

  }
  public static void main(String[] args) {
    helperTest();
    Scanner sc = new Scanner(System.in);

    System.out.println("\n Select an option:");
    System.out.println("1. Credit \n 2. Debit \n 3. Check Balance \n 4.Exit ");

    Bank[] bank = new Bank[1];
    for (int i = 0; i < 1; i++) {
      helperTest();
      bank[i] = new Bank();
    }
    int ch;
    do {
      ch = sc.nextInt();
      switch (ch) {
        case 1:
          System.out.print("Enter amount:");
          for (int i = 0; i < bank.length; i++) {
            bank[i].deposit();
          }
          break;
        case 2:
          System.out.print("Enter amount:");
          for (int i = 0; i < bank.length; i++) {
            bank[i].withdrawal();
          }
          break;
        case 3:
          System.out.print("Enter Account No : ");
          for (int i = 0; i < bank.length; i++) {
            bank[i].checkBalance();
          }
          break;
        case 4:
          System.out.println("exit...");
          break;
      }
    }
    while (ch != 5);

  }
}

