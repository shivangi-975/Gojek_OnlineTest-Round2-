package com.info.domain.model;

import java.util.Scanner;

public class Bank {
  private String accountNumber;
  private String accountPayeeName;
  private String amount;
  private long bal;

  public String getAccountNumber() {
    return accountNumber;
  }

  public String getAccountPayeeName() {
    return accountPayeeName;
  }

  public String getAmount() {
    return amount;
  }

  public long getBal() {
    return bal;
  }

  public void setBal(long bal) {
    this.bal = bal;
  }

  public void setAccountNumber(String accountNumber) {
    this.accountNumber = accountNumber;
  }

  public void setAccountPayeeName(String accountPayeeName) {
    this.accountPayeeName = accountPayeeName;
  }

  public void setAmount(String amount) {
    this.amount = amount;
  }



  Scanner sc = new Scanner(System.in);

  public void deposit() {
    long amt;
    amt = sc.nextLong();
    bal = bal + amt;
    System.out.println("Successful!");
  }

  public void withdrawal() {
    long amt;
    amt = sc.nextLong();
    if (bal >= amt) {
      bal = bal - amt;
      System.out.println("Successful!");
    } else {
      System.out.println(" balance is less than.. " + amt + "\tTransaction failed...!!" );
    }
  }

  public void checkBalance() {
    System.out.println("get Balance: " + bal);
    System.out.println("Successful!");
  }
}
